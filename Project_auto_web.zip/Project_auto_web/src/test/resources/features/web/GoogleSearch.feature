Feature: Google Search Feature

  @TestGoogle
  Scenario: Search for "hoc sinh" on Google
    Given I navigate open conf
#    When I enter search term "hoc sinh"
#    Then I click search button