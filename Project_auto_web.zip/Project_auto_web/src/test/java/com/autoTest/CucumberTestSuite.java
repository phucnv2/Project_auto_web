package com.autoTest;

import net.serenitybdd.model.environment.EnvironmentSpecificConfiguration;
import net.thucydides.model.environment.SystemEnvironmentVariables;
import net.thucydides.model.util.EnvironmentVariables;
import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.IncludeEngines;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;
import org.junit.jupiter.api.BeforeAll;

import static io.cucumber.junit.platform.engine.Constants.FILTER_TAGS_PROPERTY_NAME;
import static io.cucumber.junit.platform.engine.Constants.PLUGIN_PROPERTY_NAME;
//@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "io.cucumber.core.plugin.SerenityReporterParallel,pretty,json:target/cucumber-report/cucumber.json,html:target/cucumber-report")
//@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@smoke")
//@ConfigurationParameter(key = FILTER_NAME_PROPERTY_NAME, value = "Sample Scenario")
//@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.example.steps")
//@SelectFiles({
//        @SelectFile("src/test/resources/features/feature1.feature"),
//        @SelectFile("src/test/resources/features/feature2.feature")
//})

@Suite
@IncludeEngines("cucumber")
@SelectClasspathResource("features/web")
@ConfigurationParameter(key = "cucumber.glue", value = "com/autoTest/web/steps, com/autoTest/mobile/steps")  // Định nghĩa package chứa step definitions
@ConfigurationParameter(key = PLUGIN_PROPERTY_NAME, value = "io.cucumber.core.plugin.SerenityReporterParallel,pretty,timeline:build/test-results/timeline")
@ConfigurationParameter(key = FILTER_TAGS_PROPERTY_NAME, value = "@TestGoogle")
public class CucumberTestSuite {

}
