package com.autoTest.web.pages;

import com.autoTest.common.BasePage;
import com.autoTest.common.Constant;
import com.autoTest.common.DriverManager;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.annotations.Steps;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.testng.Assert;


public class LoginPage extends PageObject {
    private static final Logger log = LoggerFactory.getLogger(LoginPage.class);
    @Steps
    BasePage basePage;
    private final By inputUserName = By.xpath("//input[@id='user-name']");
    private final By inputPassword = By.xpath("//input[@id='password']");
    private final By buttonLogin = By.xpath("//input[@id='login-button']");
    private final By titleLoginSuccess = By.xpath("//div[@class='app_logo']");
    private final By titleLoginPage = By.xpath("//div[@class='login_logo']");
    private final By headerUserPassWrong = By.xpath("//h3[contains(text(),'Epic sadface: Username and password do not match a')]");
    private final By headerUsernameNull = By.xpath("//h3[normalize-space()='Epic sadface: Username is required']"); // cả 2 cungf null là xài cái này
    private final By headerPasswordNull = By.xpath("//h3[normalize-space()='Epic sadface: Password is required']");

    @Step
    public void openWebByDomain(String nameDomain) {
        System.out.println("1 == " +  Constant.DATA_FILE_CONF.getProperty("environment"));
        System.out.println("2 === " +  nameDomain);
        System.out.println("3 === " +  Constant.DATA_FILE_CONF.getProperty("environment") + ".domain."+ nameDomain);
        System.out.println("4 === " + String.format("%s.domain.%s", Constant.DATA_FILE_CONF.getProperty("environment"), nameDomain));
        String nameOpenWeb = Constant.DATA_FILE_CONF.getProperty(String.format("%s.domain.%s", Constant.DATA_FILE_CONF.getProperty("environment"), nameDomain));
        System.out.printf("Opened web domain: " + nameOpenWeb);
        openUrl(nameOpenWeb);
        DriverManager.setDriver(Serenity.getDriver());
    }

    @Step
    public void userInsertAndSuccess(String username, String password) {
        basePage.setText(inputUserName, username);
        basePage.setText(inputPassword, password);

    }

    @Step
    public void clickButtonLogin() {
        basePage.clickElement(buttonLogin);
    }

    @Step
    public void verifyLoginPage() {
        System.setProperty("serenity.take.screenshots", "FOR_EACH_ACTION");
//        Assert.assertEquals(getElementText(titleLoginPage),"Swag Labs","Fail! Đây không phải trang đăng nhập");
    }

    public void verifyLoginPageSuccess() {
//        Assert.assertEquals(getElementText(titleLoginSuccess),"Swag Labs","Fail! Đây không phải trang đăng nhập");
    }


    //    add new function
    @FindBy(id = "username")
    private WebElement usernameField;

    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "loginButton")
    private WebElement loginButton;

    public void enterUsername(String username) {
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        passwordField.sendKeys(password);
    }

    public void clickLogin() {
        loginButton.click();
    }

}
