package com.autoTest.web.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebElement;

public class GooglePage extends PageObject {

    @FindBy(name = "q")
    private WebElement searchBox;

    @FindBy(name = "btnK")
    private WebElement searchButton;

    public void openGoogle() {
        openUrl("https://www.google.com");
    }

    public void enterSearchKeyword(String keyword) {
        searchBox.sendKeys(keyword);
    }

    public void clickSearchButton() {
        searchButton.submit();
    }
}
