package com.autoTest.web.actions;

import com.autoTest.web.pages.GooglePage;
import net.serenitybdd.annotations.Step;

public class GoogleActions {
    GooglePage googlePage;

    @Step("Open from base url")
    public void openBaseUrl() {
        googlePage.open();
    }

    @Step("Enter search keyword {0}")
    public void enterSearchKeyword(String keyword) {
        googlePage.enterSearchKeyword(keyword);
    }

    @Step("Click search button")
    public void clickSearchButton() {
        googlePage.clickSearchButton();
    }
}