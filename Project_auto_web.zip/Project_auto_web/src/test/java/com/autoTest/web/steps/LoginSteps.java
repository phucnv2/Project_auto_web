package com.autoTest.web.steps;

import com.autoTest.web.actions.LoginActions;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Tag;

@Tag("web")
public class LoginSteps {

    LoginActions loginActions;

    @When("I enter username {string} and password {string}")
    public void enterCredentials(String username, String password) {
        loginActions.enterUsername(username);
        loginActions.enterPassword(password);
    }

    @Then("I click login button")
    public void clickLogin() {
        loginActions.clickLogin();
    }
}
