package com.autoTest.web.actions;

import com.autoTest.web.pages.LoginPage;
import net.serenitybdd.annotations.Step;

public class LoginActions {
    LoginPage loginPage;

    @Step("Enter username {0}")
    public void enterUsername(String username) {
        loginPage.enterUsername(username);
    }

    @Step("Enter password {0}")
    public void enterPassword(String password) {
        loginPage.enterPassword(password);
    }

    @Step("Click login button")
    public void clickLogin() {
        loginPage.clickLogin();
    }
}