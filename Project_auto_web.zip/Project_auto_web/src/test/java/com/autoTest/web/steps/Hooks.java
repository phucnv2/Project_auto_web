package com.autoTest.web.steps;

import com.autoTest.common.BasePage;
import com.autoTest.common.Constant;
import com.autoTest.common.DriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import net.serenitybdd.core.Serenity;

import net.serenitybdd.model.environment.EnvironmentSpecificConfiguration;
import net.thucydides.model.environment.SystemEnvironmentVariables;
import net.thucydides.model.util.EnvironmentVariables;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Tag;

@Tag("web")
public class Hooks {
    public static EnvironmentSpecificConfiguration dataConf;

    static {
        Constant.loadFileConf();
    }

    public EnvironmentVariables environmentVariables;
    public String environment;

    @Before
    public void setUp() {
        System.out.print("[INFO] Running tests in environment:"+ System.getProperty("environment"));
        System.out.println("Starting the scenario...");
        DriverManager.setDriver(Serenity.getDriver());
        beforeAll();
    }

    @After
    public void tearDown() {
        DriverManager.getDriver().quit();
        System.out.println("Ending the scenario...");
    }

    static {
        dataConf = Constant.loadFileConf();
    }

    public void beforeAll() {
        String env = System.getProperty("environment", dataConf.getProperty("serenity.environment"));
        String baseUrl = dataConf.getProperty("webdriver.base.url");
        System.out.print("env ==> " + env);
        System.out.print("baseUrl ==> " + baseUrl);
//        System.setProperty("webdriver.base.url", dataConf.getProperty("environments." + environment + ".webdriver.base.url"));
//        System.out.printf("[INFO] Running tests in environment: %s%n", environment);
    }
}
