package com.autoTest.web.steps;

import com.autoTest.web.actions.GoogleActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import net.serenitybdd.annotations.Steps;
import org.junit.jupiter.api.Tag;

@Tag("web")
public class GoogleSteps {
    @Steps
    GoogleActions googleActions;

    @Given("I navigate open conf")
    public void navigateToGoogle() {
        googleActions.openBaseUrl();
    }

    @When("I enter search term {string}")
    public void enterSearchTerm(String keyword) {
        googleActions.enterSearchKeyword(keyword);
    }

    @Then("I click search button")
    public void clickSearchButton() {
        googleActions.clickSearchButton();
    }
}

