package com.autoTest.mobile.actions;

import com.autoTest.mobile.pages.LoginPage;
import net.serenitybdd.annotations.Step;

public class LoginActions {
    LoginPage loginPage;

    @Step("Enter username {0}")
    public void enterUsername(String username) {
        loginPage.enterUsername(username);
    }

    @Step("Enter password {0}")
    public void enterPassword(String password) {
        loginPage.enterPassword(password);
    }

    @Step("Click login button")
    public void clickLogin() {
        loginPage.clickLogin();
    }
}