package com.autoTest.mobile.pages;

import io.appium.java_client.pagefactory.AndroidFindBy;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebElement;

public class LoginPage extends PageObject {

    @AndroidFindBy(id = "com.example.app:id/username")
    private WebElement usernameField;

    @AndroidFindBy(id = "com.example.app:id/password")
    private WebElement passwordField;

    @AndroidFindBy(id = "com.example.app:id/loginButton")
    private WebElement loginButton;

    public void enterUsername(String username) {
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        passwordField.sendKeys(password);
    }

    public void clickLogin() {
        loginButton.click();
    }
}
