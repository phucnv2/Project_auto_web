package com.autoTest.mobile.steps;
import com.autoTest.mobile.actions.LoginActions;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import org.junit.jupiter.api.Tag;

@Tag("mobile")
public class LoginSteps {
    LoginActions loginActions;

    @When("Mobile I enter username {string} and password {string}")
    public void enterCredentials(String username, String password) {
        loginActions.enterUsername(username);
        loginActions.enterPassword(password);
    }

    @Then("Mobile I click login button")
    public void clickLogin() {
        loginActions.clickLogin();
    }
}